#include "character.h"

Characters::Characters() {}

void Characters::loadCharacters(string filename)
{
    fstream f;
    f.open(filename);

    if(!f.is_open()) {
        perror("character file");
        return;
    }

    string line;

    getline(f, line);   // ignore header;
    while(getline(f, line)) {
        stringstream ss;
        ss << line;

        Character c;
        getline(ss, c.name, '|');

        string temp;
        getline(ss, temp, '|');
        c.stamina = stoi(temp);
        getline(ss, temp, '|');
        c.gold = stoi(temp);
        getline(ss, temp, '|');

        stringstream s;
        s << temp;
        while(getline(s, temp, ',')) {
            c.candy_names.push_back(temp);
        }

        characters.push_back(c);
    }
}

void Characters::displayCharacter(Character c)
{
    cout << "Name: " << c.name << endl;
    cout << "Stamina: " << c.stamina << endl;
    cout << "Gold: " << c.gold << endl;
    cout << "Candies:" << endl;

    int i=1;
    for(const auto &candy: c.candy_names) {
        cout << "[" << candy << "]\t";
        if(!(i++%3))
            cout << endl;
    }

    if(--i%3)
        cout << endl;
    cout << "-------------------------------------------------" << endl;
}

void Characters::displayAll()
{
    for(auto c: characters)
        displayCharacter(c);
}

Character Characters::drawCharacter(string name)
{
    int i=0;
    for( ; i<characters.size(); ++i)
        if(characters[i].name == name)
            break;
    if(i >= characters.size()) {
        cerr << "Invalid Character name!" << endl;
        exit(1);
    }
    auto ret = characters[i];
    characters.erase(i+characters.begin());
    return ret;
}



