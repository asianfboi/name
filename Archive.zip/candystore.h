#ifndef CANDYSTORE_H
#define CANDYSTORE_H

#include "character.h"
#include "defs.h"

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <map>

using namespace std;

class CandyStore
{
public:
    map<string, Candy> candiesMap{};
    vector<Candy> candies;

    CandyStore();

    void loadCandies(string file_name) ;
    void printCandy() ;
    void visit(Character &c);
    map<string, Candy> candyMap();
};

#endif // CANDYSTORE_H
