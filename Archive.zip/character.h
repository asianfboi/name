#ifndef CHARACTER_H
#define CHARACTER_H

#include "candystore.h"
#include "defs.h"

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>

using namespace std;


class Characters
{
public:

    vector<Character> characters;

    Characters();

    void loadCharacters(string filename);
    void displayCharacter(Character c);
    void displayAll();
    void mapCandiesFrom(map<string, Candy> &candies);
    Character drawCharacter(string name);
};

#endif // CHARACTER_H
