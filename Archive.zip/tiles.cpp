#include "tiles.h"

Tiles::Tiles()
{

}

void Tiles::printTile(string color, char value) {
    cout << color << " " << (value < 0 ? ' ': value) << " " << RESET;
}


void Tiles::printTiles(vector<int> playerPos) {
    //int prev_right = 0, prev_horizontal = 1;
    for(int i=0; i<tiles.size(); ++i) {
        int d= -1;

        for(int j=0; j<playerPos.size(); ++j) {
            if(playerPos[j] == i)
                d = '0' + j+1;
        }

        auto each = tiles[i];
        if(i == 24 || i == 53)
            cout << endl;

        if(each & right)
            cout << space;
        if(each & color_magenta)
            printTile(MAGENTA, d);
        if(each & color_green)
            printTile(GREEN, d);
        if(each & color_blue)
            printTile(BLUE, d);
        if(each & vertical)
            cout << endl;
    }

    cout << "\033[48;2;204;102;0m\033[38;2;0;0;0m" << "  Castle" << RESET << endl;
}

int Tiles::count()
{
    return tiles.size();
}

bool Tiles::special(int i)
{
    return tiles[i] & Special;
}

pair<int, Tiles::type> Tiles::next(string card, int pos, int &wflag)
{
    type t = color_t[card];
    int i=pos;
    for(; i<count(); ++i) {
        if(tiles[i] & t)
            break;
    }
    if(i >= count()) {
        wflag = 1;
        return {};
    }

    return {i, (type)tiles[i]};
}


void Tiles::populate()
{
    int  n = 3;
    string seq[] =  {MAGENTA, GREEN, BLUE};
    string seq2[] = {GREEN, MAGENTA, BLUE};

    // --->
    for(int i=0; i<8*3; ++i) {
        int tile = none;

        tile |= color_t[seq[i%n]];

        tiles.push_back(tile);
    }

    //      |
    //      |
    //      v
    for(int i=0; i<(2*3)-1; ++i) {
        int tile = none;
        tile |= vertical;
        tile |= right;
        tile |= color_t[seq[i%n]];

        tiles.push_back(tile);
    }

    // <---
    for(int i=0; i<8*3; ++i) {
        int tile = none;

        tile |= color_t[seq2[i%n]];

        tiles.push_back(tile);
    }

    // |
    // |
    // v
    for(int i=2; i<=(2*3); ++i) {
        int tile = none;
        tile |= vertical;
        tile |= color_t[seq[i%n]];

        tiles.push_back(tile);
    }

    // --->
    for(int i=1; i<=8*3; ++i) {
        int tile = none;
        tile |= color_t[seq[i%n]];

        tiles.push_back(tile);
    }
}
