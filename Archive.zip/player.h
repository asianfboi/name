#ifndef PLAYER_H
#define PLAYER_H

#include "candystore.h"
#include "character.h"
#include "colorTiles.h"

#include <string>

using namespace std;

class Player
{
    //int _MAX_CANDY_AMOUNT = 9;
public:
    string name = "";
    double gold = 0;
    int stamina = 0;
    int robersrepell = 0;
    Character character;
    Player();

    int pos;

    string drawCard();
    void printStats();
private:

};


#endif // PLAYER_H
