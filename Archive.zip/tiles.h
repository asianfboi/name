#ifndef TILES_H
#define TILES_H

#include "colorTiles.h"

#include <string>
#include <iostream>
#include <vector>
#include <map>

using namespace std;

class Tiles
{
public:
    enum type 
    {
        HiddenTresure = 1 << 1,
        CandyStore = 1 << 2,
        Regular = 1 << 5,
        Special = 1 << 6,
        Shortcut = Special | 1<<7,
        IceCreamStop = Special | 1<<8,
        GumdropForest = Special | 1<<9,
        GingerbreadHouse = Special | 1<<10,

        // display data
        vertical = 1 << 3,
        right = 1 << 4,

        color_magenta = 1 << 14,
        color_green = 1 << 15,
        color_blue = 1 << 16,

        none = 0
    };

    map<string, type> color_t 
    {
        {MAGENTA, type::color_magenta},
        {GREEN, type::color_green},
        {BLUE, type::color_blue}
    };

    string space = string(69, ' ');
    vector<int> tiles;
    Tiles();

    void populate();
    void printTile(string, char value);
    void printTiles(vector<int> playerPos);

    int count();
    bool special(int i);

    pair<int, type> next(string card, int pos, int &wflag);
};

#endif // TILES_H
