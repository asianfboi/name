#include "candystore.h"


CandyStore::CandyStore()
{

}

void CandyStore::loadCandies(string file_name)
{
    ifstream inputFile(file_name);

    if (!inputFile.is_open()) {
        perror("candy file");
        return;
    }

    string line;
    getline(inputFile, line);   // skip header
    while (getline(inputFile, line))
    {
        if(line != "")
        {
            stringstream ss (line);
            string price;
            Candy candy;
            getline( ss,candy.name,'|');
            getline( ss, candy.description, '|');
            getline( ss, candy.effect_type, '|');

            string temp;
            getline( ss, temp, '|');
            candy.effect_value = stoi(temp);
            getline( ss, candy.candy_type, '|');
            getline( ss, temp, '|');
            candy.price = stoi(temp);

            this->candies.push_back(candy);
            this->candiesMap[candy.name] = candy;
        }


    }
}

void CandyStore::printCandy() {
    for(int i = 0; i<candies.size(); i++){
        Candy c = candies[i];
        cout << "Name: " << c.name << endl;
        cout << "Description: " << c.description << endl;
        cout << "Effect: " << c.effect_type << endl;
        cout << "Effect value: " << c.effect_value << endl;
        cout << "Candy type: " << c.candy_type << endl;
        cout << "Price: " << c.price << endl;
        cout << "-------------------------------------------------" << endl;
    }
}

void CandyStore::visit(Character &c)
{
    cout << "Here is a list of candies in the candy store:" << endl;
    printCandy();
    cout << endl << endl;
    cout << "Which candy would you like to buy?" << endl;
    string candy_name;
    fflush(stdin);
    fflush(stdout);
	getline(cin, candy_name);
    getline(cin, candy_name);

    if(c.candies.size() == 9) {
        cout << "You do not have sufficient place in the candy inventory. Would you like to substitute your candy with any existing candy?(y/n)" << endl;
        string choice;
        cin >> choice;
        if(choice[0] == 'y' || choice[0] == 'Y') {
            cout << "Which candy would you like to substitute?" << endl;
            string temp;
            cin >> temp;
            c.gold -= candiesMap[choice].price;
            c.substitute(temp, candiesMap[choice]);
        }
    } else {
        cout << "You have successfully bought " << candy_name << endl;
        c.addCandy(candiesMap[candy_name]);
        c.gold -= candiesMap[candy_name].price;
    }
}

map<string, Candy> CandyStore::candyMap()
{
    for(auto each: candies)
        this->candiesMap[each.name] = each;

    return candiesMap;
}

