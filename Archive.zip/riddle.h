#ifndef RIDDLE_H
#define RIDDLE_H

#include <string>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

class Riddles
{
public:
    struct Riddle 
    {
        string riddle, ans;
    };
    vector<Riddle> riddles;

    Riddles();
    void readRiddles(string filename);

    Riddle getRandom();
};

#endif // RIDDLE_H
