#include <iostream>

#include "player.h"
#include "candystore.h"
#include "riddle.h"
#include "tiles.h"
#include "character.h"
#include "colorTiles.h"

using namespace std;

int nextVacentTile(Tiles &t) {
    int max = t.count();
    srand(time(0));
    // shortcut tile
    int idx;
    do {
        idx = rand() % (max-3);
    } while(t.special(idx));

    return idx;
}
void spreadSpecialTiles(Tiles &t) {
    // shortcut tile
    int idx = nextVacentTile(t);
    t.tiles[idx] |= Tiles::Special;
    t.tiles[idx] |= Tiles::Shortcut;

    // ice cream stop
    idx = nextVacentTile(t);
    t.tiles[idx] |= Tiles::Special;
    t.tiles[idx] |= Tiles::IceCreamStop;

    // gumdrop forest tile
    idx = nextVacentTile(t);
    t.tiles[idx] |= Tiles::Special;
    t.tiles[idx] |= Tiles::GumdropForest;

    // hidden treasure
    idx = nextVacentTile(t);
    t.tiles[idx] |= Tiles::Special;
    t.tiles[idx] |= Tiles::HiddenTresure;

    // candy store
    idx = nextVacentTile(t);
    t.tiles[idx] |= Tiles::Special;
    t.tiles[idx] |= Tiles::CandyStore;
}

int main(){
    Tiles t;
    t.populate();
    int total_tiles = t.count();
    int special_tiles = total_tiles *.25;

    int cnt = special_tiles/5;

    while(cnt--)
        spreadSpecialTiles(t);

    Characters characters;
    CandyStore candyStore;
    Riddles riddles;

//    Loading the game components
    characters.loadCharacters("characters.txt");
    candyStore.loadCandies("candies.txt");
    riddles.readRiddles("riddles.txt");

    for(auto &c : characters.characters)
        c.mapCandiesFrom(candyStore.candiesMap);

//    Selecting the characters
    int nPlayers;
    cout << "Welcome to the game of Candyland. Please enter the number of participants\n";
    cin >> nPlayers;
    vector<Player> players = vector<Player> (nPlayers);
    for(int i=0; i<nPlayers; ++i) {
        cout << "Enter player name:" << endl;
        cin >> players[i].name;
        cout << "Awesome! Here is a list of character a player can select from: " << endl;
        characters.displayAll();
        cout << "The selected character is" << endl;
        string temp;
        cin >> temp;
        auto c = characters.drawCharacter(temp);
        players[i].character = c;
        players[i].pos = i;

        cout << "Do you want to visit candy store?(y/n)" << endl;
        cin >> temp;
        if(temp[0] == 'Y' || temp[0] == 'y') {
            candyStore.visit(players[i].character);
        }
    }
    int game = 1;
    while (game) {
        for(int i=0; i<players.size(); ++i) {
            printf("It's %s turn\n", players[i].name.c_str());
            cout << "Please Select menu option:" << endl;
            cout << "1. Draw a card" << endl;
            cout << "2. User candy" << endl;
            cout << "3. Show player stats" << endl;

            int choice;
            cin >> choice;
            if(choice == 1) {
                string D;
                cout << "To draw a card press D" << endl;
                cin >> D;
                if(D != "D")
                    continue;

                auto card = players[i].drawCard();
                players[i].stamina--;   // 1unit

                cout << "You drew a ";
                pair<int, Tiles::type> next;
                int won = 0;
                if(card == BLUE) {
                    // Bubblegum Blue
                    cout << "Bubblegum Blue card. You game peice advance to Blue tile. Here is updated trail." << endl;
                } else if(card == GREEN) {
                    // Minty Green
                    cout << "Minty Green card. You game peice advance to Green tile. Here is updated trail." << endl;
                } else {
                    // Cotton Candy Magenta
                    cout << "Cotton Candy Magenta card. You game peice advance to Magenta tile. Here is updated trail." << endl;
                }

                next = t.next(card, players[i].pos, won);
                players[i].pos = next.first;

                if(won) {
                    cout << "Player " << players[i].name << " has reached the castle!" << endl;
                    exit(0);
                }
                vector<int> pos;
                for(int i=0; i<nPlayers; ++i)
                    pos.push_back(players[i].pos);

                t.printTiles(pos);

                Tiles::type tile = next.second;
                if(tile & Tiles::Special) {
                    if(tile & Tiles::Shortcut) {
                        cout << "You steped on Shortcut!" << endl;
                        if(players[i].pos+4 >= t.count()) {
                            won = 1;
                            break;
                        }
                        players[i].pos += 4;
                    } else if(tile & Tiles::IceCreamStop) {
                        cout << "You steped on Ice Cream Stop! You get another turn!" << endl;
                        i--;
                        continue;
                    } 
                    else if(tile & Tiles::GumdropForest) 
                    {
                        cout << "Oops! You steped on Gum drop Forest!" << endl;
                        srand(time(0));

                        int lost_gold = 5+rand()%5;
                        cout << "You loss " << lost_gold << " gold" << endl;
                        players[i].gold -= lost_gold;
                    } 
                    else if(tile & Tiles::HiddenTresure) 
                    {
                        cout << "You steped on a hidden treasure!" << endl;
                        cout << "Do you accept the challange?(y/n)";
                        string choice;
                        cin >> choice;
                        int wonCh = 0;
                        if(choice[0] == 'y' || choice[0] == 'Y') {
                            int rock=1,paper=2,sessiors=3;
                            cout << "1. Play rock paper sessiors" << endl;
                            cout << "2. Guess a riddle" << endl;
                            int choice;
                            cin >> choice;
                            if(choice == 1) {
                                cout << "Rock paper sessiors it is!" << endl;
                                cout << "Enter rock=1, paper=2, sessiors=3 ? ";
                                int c;
                                cin >> c;
                                srand(time(0));
                                int computer_guess = 1+(rand() % 3);
                                if((c == rock && computer_guess == paper) || (c == paper && computer_guess == sessiors) || (c == sessiors && computer_guess == rock)) 
                                    {
                                        cout << "You lost against computer!\n";
                                        wonCh = 1;
                                    } 
                                    else 
                                    {
                                        cout << "You won against computer!\n"; // Assuming this was the intention for the "else" case
                                    }

                            } else if(choice == 2) {
                                auto r = riddles.getRandom();
                                cout << "Question: " << r.riddle << endl;
                                cout << "Your ans: ";
                                string ans;
                                cin >> ans;
                                if(ans == r.ans) {
                                    cout << "You gussed correctly!" << endl;
                                    wonCh = 1;
                                } else {
                                    cout << "Wrong Guess! you loss!" << endl;
                                }
                            }
                        }

                        if(wonCh == 1) {
                            srand(time(0));
                            int chance = rand()%100;
                            if(chance > 0 && chance <= 30) {
                                // stamina refill
                                int stamina = 10+(rand() %20);
                                cout << "You have got stamina refill of " << stamina << endl;
                            } else if(chance > 30 && chance <= 40) {
                                // gold windfall
                                srand(time(0));
                                int gold_won = 20+(rand() %20);
                                cout << "You have won " << gold_won << " gold" << endl;
                            } else if(chance > 40 && chance <= 70) {
                                // robers repell
                                players[i].robersrepell++;
                            } else {
                                // candy!
                                if(chance < 70 + (30*.7)) {
                                    players[i].character.addCandy(candyStore.candiesMap["Jellybean of Vigor"]);
                                } else {
                                    players[i].character.addCandy(candyStore.candiesMap["Treasure Hunter's"]);
                                }
                            }
                        }
                    }
                } 
                else 
                {
                    srand(time(0));
                    int chance = rand() % 100;

                    if(chance <= 40) {
                        // clamity!
                        srand(time(0));
                        int chance = rand() % 100;

                        if(chance > 0 && chance <= 30)
                        {
                            cout << "Oh no! Candy Bandits have swiped your gold coins!" << endl;
                        } else if(chance > 30 && chance <= 65) {
                            cout << "Oh dear! You got lost in the lollipop labyrinth!" << endl;
                        } else if(chance > 65 && chance <= 80) {
                            cout << "Watch out! A candy avalanche has struck!" << endl;
                        } else {
                            cout << "Oops! You are stuck in a sticky taffy trap!" << endl;
                        }
                    }
                }
            } else if (choice == 2) {
                cout << "Here is the list of candies" << endl;
                int i=0;
                for(const auto &each: players[i].character.candies) {
                    cout << each.name << "\t";
                    if(!(i%3))
                        cout << endl;
                }
                cout << "Enter the candy you wish to use:";
                string temp;
                cin >> temp;

                Candy c = players[i].character.drawCandy(temp);
                if(c.effect_type == "poision") {
                    cout << "Do you wish to use " << temp << " candy against your oppnenet?(y/n)" << endl;
                    string choice;
                    cin >> choice;
                    if(choice[0] == 'y' || choice[0] == 'Y') {
                        for(int j=0; j<players.size(); ++j) {
                            if(j==i)    continue;
                            players[j].stamina += c.effect_value;
                        }
                    }
                } else if(c.effect_type == "magical") {
                    players[i].stamina += c.effect_value;
                } else if(c.effect_type == "stamina") {
                    players[i].stamina += c.effect_value;
                }
            } 
            else if(choice == 3) {
                players[i].printStats();
            } 
            else 
            {
                cerr << "Invalid choice!" << endl;
            }
        }

    }
    // n player
    // move players
    // - regular tile - 40% clamity
}
