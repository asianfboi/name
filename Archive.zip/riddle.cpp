#include "riddle.h"

Riddles::Riddles()
{

}

void Riddles::readRiddles(string filename)
{
    fstream f;
    f.open(filename);
    if(!f.is_open()) {
        perror("riddle file");
        return;
    }

    string line;
    getline(f, line);   // skip header

    while(getline(f, line)) {
        Riddle r;
        stringstream ss;
        ss << line;
        getline( ss , r.riddle, '|');
        getline( ss , r.ans, '|');

        riddles.push_back(r);
    }
}

Riddles::Riddle Riddles::getRandom()
{
    srand(time(0));
    int r = rand() % riddles.size();
    return riddles[r];
}
