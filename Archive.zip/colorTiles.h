#ifndef COLORTILES_H
#define COLORTILES_H

// Define these on top of your file before any functions

#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define RESET "\033[0m"

#endif // COLORTILES_H
