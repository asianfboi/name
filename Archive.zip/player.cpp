#include "player.h"


Player::Player() {
    stamina = 0;
    gold = 0 ;
    Candy candies;
}

string Player::drawCard()
{
    int i=0;
    srand(time(0));
    i = rand() % 3;
    string seq[] =  {MAGENTA, GREEN, BLUE};
    return seq[i];
}

void Player::printStats()
{
    cout << "Player name: " << name << endl;
    cout << "Character: " << character.name << endl;
    cout << "Stamina:" << character.stamina << endl;
    cout << "Gold: " << character.gold << endl;

    int i=1;
    for(const auto &candy: character.candies) {
        cout << "[" << candy.name << "]\t";
        if(!(i++%3))
            cout << endl;
    }
}
