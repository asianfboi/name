#ifndef DEFS_H
#define DEFS_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
using namespace std;

class Candy 
{
    public:
        string name, description, candy_type, effect_type;
        double price = 0;
        int effect_value;
};

struct Character
{
    string name;
    int stamina, gold;
    vector<string> candy_names;
    vector<Candy> candies;


    void mapCandiesFrom(map<string, Candy> &candies) 
    {
        for(auto e: candy_names) {
            this->candies.push_back(candies[e]);
        }
    }

    void substitute(string from, Candy to) 
    {
       int i = 0; // i is declared here 
        for( ; i < candies.size(); i ++)// ; is the same thing as int i = 0; just int i = 0; indfenifted above 
        {
            if(candies[i].name == from)
            {
                // if candy is found it will break out of the loop 
                break;
            }
        }
        // Check if the loop ended without finding a candy with the specified name
        if(i >= candies.size())
        {
            cout << "Invalid candy name!" << endl;
            return;
        }
        // If the candy with the specified name is found, replace it with the new candy 'to'
        candies[i] = to;
    }

    void addCandy(Candy c) 
    {
        candies.push_back(c);
    }

    Candy drawCandy(string candyName) 
    {
        int i=0;
        for( ;i < candies.size(); ++i)
        {
            if(candies[i].name == candyName)
            {
                // if name is found breaks out of loop
                break;
            }
        }
        if(i >= candies.size()) 
        {
            cerr << "Invalid candy name" << endl;
            exit(1);
        }

        Candy  c = candies[i]; // the candy that found it will be stored in the varaible 'c'
        //(i + candies.begin()) gives an iterator pointing to the position in the vector determined by the index i.
        candies.erase(i + candies.begin());// i + candies.begin() gives you postion of the index that the erase function will remove
        return c;
    }
};

#endif // DEFS_H
